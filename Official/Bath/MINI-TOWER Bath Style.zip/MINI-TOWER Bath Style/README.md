I using 22,5 angle for all walls.<br>
If you would like less angular walls, you can continue red-line blocks with walls. Otherwise, just delete them.<br>

If you would like continue walls, you can do this:
![alt text](image.png)